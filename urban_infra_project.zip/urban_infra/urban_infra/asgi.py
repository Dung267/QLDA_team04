import os
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
import notifications.routing
import flood.routing

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'urban_infra.settings')

application = ProtocolTypeRouter({
    'http': get_asgi_application(),
    'websocket': AuthMiddlewareStack(
        URLRouter(
            notifications.routing.websocket_urlpatterns +
            flood.routing.websocket_urlpatterns
        )
    ),
})

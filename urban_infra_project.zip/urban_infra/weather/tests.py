from django.test import TestCase

# Tests for weather
